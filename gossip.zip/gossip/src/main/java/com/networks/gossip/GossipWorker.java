package com.networks.gossip;

public class GossipWorker extends Thread{

    GossipData gossipData;
    GossipWorker (GossipData gossipData){
        this.gossipData=gossipData;
    }

    public void run(){
        System.out.println("\nGossip Worker: In Gossip worker:" + gossipData.userString + "\n");
    }
}
