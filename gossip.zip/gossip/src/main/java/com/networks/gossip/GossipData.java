package com.networks.gossip;

import java.io.Serializable;

public class GossipData implements Serializable {

    int nodeNumber;
    int average;
    int highValue;
    int lowValue;
    String userString;

}
