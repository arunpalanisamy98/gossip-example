package com.networks.gossip;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class GossipStarter {

    public static int serverPort = 45565;
    public static int NodeNumber = 0;

    public static void main(String[] args) throws Exception{
        System.out.println(
                "clark Elliot's Gossip Server 1.0 starting up, listening at port "+ GossipStarter.serverPort +".\n"
        );

        ConsoleLooper CL = new ConsoleLooper();
        Thread t = new Thread(CL);
        t.start();

        boolean loopControl = true;

        try{
            DatagramSocket DGSocket = new DatagramSocket(GossipStarter.serverPort);
            System.out.println("SERVER: Re eive Buffer size: "+DGSocket.getReceiveBufferSize() + "\n");
            byte[] incomingData = new byte[1012];
            //InetAddress IPAdress = InetAddress.getByName("localhost");


            while(loopControl){
                DatagramPacket incomingPacket = new DatagramPacket(incomingData, incomingData.length);
                DGSocket.receive(incomingPacket);
                byte[] data = incomingPacket.getData();
                ByteArrayInputStream in = new ByteArrayInputStream(data);
                ObjectInputStream is = new ObjectInputStream(in);
                GossipData gossipObj = (GossipData) is.readObject();

                if(gossipObj.userString.indexOf("stopserver")>-1){
                    System.out.println("SERVER: Stopping UDP listner now. \n");
                    loopControl = false;
                }

                System.out.println("\nSERVER: Gossip object received = " + gossipObj.userString + "\n");
                new GossipWorker(gossipObj).start();
                }
            }catch (Exception e){
            e.printStackTrace();
        }

    }
}
