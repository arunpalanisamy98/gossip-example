package com.networks.gossip;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class ConsoleLooper implements Runnable{

    @Override
    public void run() {
        System.out.println("CL: In the Console Looper Thread");


    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        try{
            String someString;
            do{
                System.out.println(
                        "CL: Enter a string to send to the gossipServer, (or, quit/ stopserver): "
                );
                //TODO("need to learn what it does")
                System.out.flush();
                someString = in.readLine();

                if(someString.indexOf("quit")> -1){
                    System.out.println("CL: Exiting now by user request.\n");
                    System.exit(0);
                }

                System.out.println("CL: Preparing the datagram packet now... ");
                DatagramSocket DGSocket = new DatagramSocket();
                InetAddress IPAdress = InetAddress.getByName("localhost");

                GossipData gossipObj = new GossipData();
                gossipObj.userString = someString;

                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                ObjectOutputStream os = new ObjectOutputStream(outputStream);
                os.writeObject(gossipObj);
                byte[] data = outputStream.toByteArray();
                DatagramPacket sendPacket = new DatagramPacket(data, data.length, IPAdress, GossipStarter.serverPort);
                DGSocket.send(sendPacket);
                System.out.println("CL: Datagram has been sent.");
            }while(true);
        }catch (Exception e){
            e.printStackTrace();
        }



    }
}
